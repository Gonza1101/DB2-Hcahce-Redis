package tp3_Redis.skynet_Redis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkynetRedisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkynetRedisApplication.class, args);
	}

}
