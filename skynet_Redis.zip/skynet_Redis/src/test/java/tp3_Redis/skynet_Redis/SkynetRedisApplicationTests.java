package tp3_Redis.skynet_Redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkynetRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
