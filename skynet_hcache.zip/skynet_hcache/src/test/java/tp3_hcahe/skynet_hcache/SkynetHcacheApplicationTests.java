package tp3_hcahe.skynet_hcache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkynetHcacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
