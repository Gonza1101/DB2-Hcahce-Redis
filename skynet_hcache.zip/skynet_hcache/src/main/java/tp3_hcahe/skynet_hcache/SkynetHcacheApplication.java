package tp3_hcahe.skynet_hcache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkynetHcacheApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkynetHcacheApplication.class, args);
	}

}
